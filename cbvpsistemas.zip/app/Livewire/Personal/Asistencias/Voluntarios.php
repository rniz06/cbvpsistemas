<?php

namespace App\Livewire\Personal\Asistencias;

use App\Exports\Excel\Personal\Asistencias\ExcelAsistenciasExport;
use App\Exports\Pdf\Personal\Asistencias\ListaDeAsistenciaPorPeriodoParaRemitirExport;
use App\Models\Personal\Asistencia\Asistencia;
use App\Models\Personal\Asistencia\Detalle;
use Livewire\Attributes\On;
use Livewire\Component;
use Livewire\Livewire;
use Livewire\WithPagination;
use Maatwebsite\Excel\Facades\Excel;

class Voluntarios extends Component
{
    use WithPagination;

    // REGISTRO
    public $asistencia;

    // PROPIEDADES DE FILTRADO
    public $buscarNombreCompleto, $buscarCodigo, $paginado = 10;

    // PROPIEDADES PARA EL BLOQUEO
    public $bloqueoBtnCargar = true, $bloquearBtnCargarPorFichaActualizar = false, $bloqueoBtnEnviar = false;

    // PROPIEDADES PARA MENSAJES DE ALERTA PERMANENTE
    public $mostrarMensajeAleta = false;

    # PROPIEDADES PARA EL MODAL DE CARGA DE ASISTENCIA
    public $detalle = null;

    #[On('abril-modal-carga')]
    public function habilitar_form_carga($detalle)
    {
        $this->detalle = $detalle;
    }

    #[On('asistencia-cargada')]
    public function cerra_modal()
    {
        $this->detalle = null;
    }

    public function mount($asistencia)
    {
        // OBTENER REGISTRO ACTUAL
        $this->asistencia = Asistencia::select(
            'id_asistencia',
            'compania_id',
            'periodo_id',
            'estado_id',
            'hubo_citacion',
            'tipo_asistencia'
        )            ->with([
                'compania:id_compania,compania',
                'estado:id_asistencia_estado,estado',
                'periodo.anho:id_anho,anho',
                'periodo.mes:id_mes,mes',
            ])->findOrFail($asistencia);

        # SI EL ESTADO ES "SIN CARGAR" HABILITA BTN PARA LA CARGA, SI ES DISTINTO PERMANECE BLOQUEADO
        if ($this->asistencia->estado_id == 2 or $this->asistencia->estado_id == 5) { // SIN CARGAR - RECHAZADO POR PERSONAL
            $this->bloqueoBtnCargar = false;
        }

        // CONSULTA PARA VERIFICAR QUE NO EXISTEN FICHAS QUE FALTEN ACTUALIZAR
        $pendiente = Detalle::where('asistencia_id', $this->asistencia->id_asistencia)
            ->whereRelation('personal', 'estado_actualizar_id', 1)
            ->exists();

        // COMPROBAR RESULTADO DE LA CONSULTA ANTERIOR
        if ($pendiente) {
            $this->mostrarMensajeAleta = true;
        }

        // CONSULTA PARA VERIFICAR QUE NO EXISTEN FICHAS POR CARGAR ASISTENCIA
        $enviar = Detalle::where('asistencia_id', $this->asistencia->id_asistencia)
            ->whereNotNull('total')
            ->exists();

        // COMPROBAR RESULTADO DE LA CONSULTA ANTERIOR
        if ($enviar) {
            $this->bloqueoBtnEnviar = true;
        }

        # SI EL ESTADO ES DISTINTO A "SIN CARGAR", BLOQUEA EL BOTON ENVIAR
        if ($this->asistencia->estado_id != 2) { // SIN CARGAR
            $this->bloqueoBtnEnviar = true;
        }
    }

    // Limpiar el buscador y la paginación al cambiar de pagina
    public function updating($key): void
    {
        if (in_array($key, [
            'buscarNombreCompleto',
            'buscarCodigo',
            'paginado'
        ])) {
            $this->resetPage('personales_page');
        }
    }

    public function render()
    {
        return view('livewire.personal.asistencias.voluntarios', [
            'voluntarios' => Detalle::select('id_asistencia_detalle', 'personal_id', 'asistencia_id', 'practica', 'guardia', 'citacion', 'total')
                ->with([
                    'personal:idpersonal,nombrecompleto,codigo,categoria_id,fecha_juramento,estado_id,estado_actualizar_id',
                    'personal.estado:idpersonal_estados,estado',
                    'personal.categoria:idpersonal_categorias,categoria'
                ])
                ->where('asistencia_id', $this->asistencia->id_asistencia)
                ->buscarNombrecompleto($this->buscarNombreCompleto)
                ->buscarCodigo($this->buscarCodigo)
                ->paginate($this->paginado, ['*'], 'personales_page')
        ]);
    }

    public function enviar()
    {
        $this->asistencia->update([
            'estado_id' => 3, // REMITIDO P/ VERIFICAR
        ]);
        session()->flash('success', 'Remitido Correctamente!');
        $this->redirectRoute('personal.asistencias.show', $this->asistencia->id_asistencia);
    }

    // Obtener lo datos para los reportes pdf y excel
    public function cargarDatosExport()
    {
        return Detalle::select('id_asistencia_detalle', 'personal_id', 'asistencia_id', 'practica', 'guardia', 'citacion', 'total')
            ->with([
                'personal:idpersonal,nombrecompleto,codigo,estado_actualizar_id,categoria_id,fecha_juramento',
                'personal.categoria:idpersonal_categorias,categoria'
            ])
            ->where('asistencia_id', $this->asistencia->id_asistencia)->get();
    }

    public function pdf()
    {
        $query = $this->cargarDatosExport();
        $nombre_archivo = "Asistencia";

        $periodo = $this->asistencia->periodo->mes->mes . '/' . $this->asistencia->periodo->anho->anho;
        $compania = $this->asistencia->compania->compania;
        $hubo_citacion = $this->asistencia->hubo_citacion;

        return (new ListaDeAsistenciaPorPeriodoParaRemitirExport($query, $nombre_archivo, $periodo, $compania, $hubo_citacion))->download();
    }
}
