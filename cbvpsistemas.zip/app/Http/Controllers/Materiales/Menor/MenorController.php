<?php

namespace App\Http\Controllers\Materiales\Menor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class MenorController extends Controller
{
    /**
     * Establece los middleware necesarios para gestionar permisos
     * Se utilizan permisos específicos para cada acción del controlador.
     */
    function __construct()
    {
        $this->middleware('permission:Material Menor Listar', ['only' => ['index']]);
        $this->middleware('permission:Material Menor Ver Compania', ['only' => ['verCompania']]);
    }

    public function index()
    {
        return view('materiales.menor.menor.index');
    }

    public function verCompania($compania)
    {
        return view('materiales.menor.menor.ver-compania', compact('compania'));
    }
}
